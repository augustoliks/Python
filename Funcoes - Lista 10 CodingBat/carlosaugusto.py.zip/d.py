def double_char(s):
	sq = list(s)
	k = 0
	vetor = []

	while k < len(s) :
		vetor.append( sq[k] )
		vetor.append( sq[k] )
		k+=1 
	return "".join(vetor)

while True:
	p= input ("Digite uma palavra: ")
	print( double_char(p) )
	
